# Alexandria Weather Studio: deploying the Task 5 forecast model with Django

A Django web app that wraps the **SARIMA-F temperature model from Task 5** (plus companion models for humidity, cloud cover,
wind and rain) in a modern weather-app interface: an animated sky that matches the forecast, a big temperature, Apple-Weather-style
hourly and 7-day cards, detail tiles, a confidence chart and a rotating Earth globe showing the state of the atmosphere over Alexandria.

![Default view](docs/screenshots/01_desktop_default.png)

| Thunderstorm scenario | Heatwave scenario |
|---|---|
| ![Storm](docs/screenshots/02_desktop_storm.png) | ![Heatwave](docs/screenshots/03_desktop_heatwave.png) |

More states are in [`docs/screenshots/`](docs/screenshots/): windy, clear night (tap an evening hour), inline validation errors and the mobile layout.

---

## 1. Run it locally (5 minutes)

Requirements: **Python 3.12** (the saved model files were created with the exact library versions in `requirements.txt`).

```bash
git clone <your-repo-url> weather_forecast && cd weather_forecast
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py runserver
```

Open <http://127.0.0.1:8000/>. The trained models are already included in `forecast/artifacts/`, so nothing else is needed.

Run the automated tests (model parity with the notebook, form validation, views, JSON API, weather logic):

```bash
python manage.py test
```

Retrain every model from the data (takes about 2 minutes) if you change the data or your library versions differ:

```bash
python manage.py train_models
```

---

### Publishing to GitHub (deliverable)
```bash
cd weather_forecast
git init -b main
git add .
git commit -m "Task 6: Alexandria Weather Studio"
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

---

## 2. How to use the app

1. **Pick a forecast date** (2 Dec 2025 to 31 Dec 2027). Without anything else you get the model's seasonal-climate forecast.
2. *(Optional)* enter the **readings from the day before** (temperature, humidity, wind, cloud cover, rain). The model is conditioned on them, which makes the first days of the forecast much more accurate.
3. Or press a **scenario button** (Heatwave, Storm, Windy, Overcast, Clear) to see the background, icons and globe change.
4. **Tap an hour** in the hourly strip: the big number, the sky (day / night) and the background update.
5. Choose **ARIMA** in the *Model* dropdown to compare against the baseline (bonus: multiple models).

Everything is submitted with a normal `GET` form, so every forecast has a **shareable URL**.

### What the interface shows
* **Hero:** the predicted **mean temperature** (the model's main target), the weather condition (sunny, partly cloudy, cloudy, windy, showers, rain, thunderstorm, hot), high/low, the 95 % range and a confidence label.
* **Animated background** that matches the condition and time of day: sun / moon and stars, drifting clouds, rain, lightning and wind streaks.
* **Hourly temperatures** with sunrise and sunset markers (estimated, see "Honest limitations").
* **7-day forecast** with colour-coded temperature range bars and rain chances.
* **Detail tiles:** temperature (emphasised), humidity, cloud cover, precipitation, wind (Beaufort scale) and sun times.
* **Chart:** 7-day temperature with the 95 % confidence band (bonus: model confidence chart).
* **Globe:** a rotating Earth built from real continent outlines. The glow colour is the **state of the atmosphere** (Clear & dry, Fair, Humid, Overcast, Breezy, Unsettled, Turbulent), cloud patches follow the forecast cloud cover, and Alexandria is pinned.

---

## 3. JSON API (bonus)

```
GET /api/forecast/?date=2026-12-15&temperature=14.5&humidity=88&wind_speed=6&cloud_cover=90
```

Returns `{"ok": true, "meta": {...}, "daily": [...7 days...], "hourly": [...24 hours...], "atmosphere": {...}}`.
Invalid input returns HTTP 400 with `{"ok": false, "errors": {...}}`. Parameters are the same as the form fields:
`date` (required), `model` (`temperature` or `temperature_arima`), `temperature`, `humidity`, `wind_speed`, `cloud_cover`, `precipitation`.

**Caching (bonus):** identical inputs are served from a cache (`meta.cached = true`, shown as an "instant" chip in the UI).

---

## 4. Project structure (separation of concerns)

```
weather_forecast/
├── manage.py
├── requirements.txt · Procfile · build.sh · render.yaml · .python-version
├── config/                      Django project (settings, urls, wsgi/asgi)
├── data/alexandria_weather_clean.csv     Task 4 dataset (NASA POWER, 2021-2025)
├── notebooks/Task5_Forecasting.ipynb     the Task 5 notebook the model comes from
└── forecast/                    the app
    ├── forms.py                 INPUT: Django form + validation rules and messages
    ├── views.py                 HTTP: page view and JSON API (thin, no ML code)
    ├── urls.py · apps.py        routes; loads the models once at start-up
    ├── ml/
    │   ├── predictor.py         ML: model registry, raw numeric forecasts
    │   ├── train.py             ML: training and saving all models
    │   ├── weather_logic.py     DOMAIN: condition rules, scene, hourly curve, atmosphere
    │   ├── astro.py             sunrise / sunset
    │   ├── service.py           builds the page/API payload (+ caching)
    │   └── common.py            Fourier features, cleaning (same as the notebook)
    ├── artifacts/               saved models (.joblib), metadata.json, notebook reference forecast
    ├── templates/forecast/      index.html + SVG icon sprite
    ├── static/forecast/         app.css, sky.js (animated sky), globe.js, app.js, land.json
    └── tests.py                 automated tests
```

ML logic (`ml/`), forms (`forms.py`) and views (`views.py`) never mix: the view validates with the form, asks the service for a payload, and renders.

---

## 5. The models

| What | Model | Notes |
|---|---|---|
| **Temperature (main target)** | **SARIMA-F**: SARIMAX(2,1,1) + 1 yearly sine/cosine pair | Exactly the Task 5 model, trained on data up to 2025-12-01. **30-day hold-out MAE 0.73 °C** |
| Temperature (alternative) | ARIMA(1,0,0) + constant, no seasonality | Baseline in the model dropdown. *Differs slightly from the Task 5 baseline, which had no constant (that version drifts to 0 °C for distant dates)* |
| Daily min / max | Daily mean ± a modelled day/night range (SARIMAX(1,0,1) + 2 harmonics) | |
| Humidity, wind, cloud cover | SARIMAX + yearly harmonics, order chosen by walk-forward validation on the training data | Beat "same as yesterday". Humidity and wind are about as good as the seasonal average over 7 days (humidity 4.8 vs 4.3 %, wind 0.94 vs 0.91 m/s); cloud cover beats it (15.6 vs 16.6 %). Their main job is to carry your observation into the next days |
| Rain chance | Logistic regression on season + forecast cloud cover + humidity (+ a wet-spell boost the day after rain) | Brier score 0.061 vs 0.077 for the base rate. Amount from typical wet-day amounts by month |

**Why "SARIMA-F"?** The data is daily with a yearly cycle (period about 365), which a classic seasonal SARIMA cannot fit practically.
Sine/cosine terms handle the yearly cycle and the ARIMA part models the day-to-day dynamics (dynamic harmonic regression).

**How your readings are used.** The model was fitted up to 2025-12-01. If you give the readings of the day before the forecast date, the fitted model
is *extended* to that day (the days in between are treated as missing, which the Kalman filter handles natively) and forecasts from there. The parameters are never
re-estimated, so predictions with no readings reproduce the notebook exactly. The test `test_forecast_matches_task5_notebook_output` checks this against the saved reference forecast.

### Matching the notebook (rubric: "predictions match notebook output")
Open the app with the date **2025-12-02** and no readings: the 30 forecasts (2-31 Dec 2025) are identical to the Task 5 test forecast
(`forecast/artifacts/notebook_reference_forecast.csv`, difference below 1e-6).

---

## 6. Input validation and edge cases

| Case | Behaviour |
|---|---|
| Empty form / missing date | Inline message: "Choose the date you want a forecast for." |
| Non-numeric text (`abc`) | "Enter a valid number, e.g. 24.5." |
| Out-of-range values | e.g. "Humidity must be between 0 and 100 %." (temperature -5 to 50 °C, wind 0 to 40 m/s, cloud 0 to 100 %, rain 0 to 300 mm) |
| Date outside the supported range | "Pick a date between 02 Dec 2025 and 31 Dec 2027." |
| Readings with the very first date | Explained: readings describe the day *before* the forecast date |
| Any error | The page stays alive (default forecast behind the form), fields are highlighted and the first bad field is focused |

Validation runs twice: instantly in the browser (JavaScript, on blur / submit) and always on the server (Django form), so the API and a disabled-JS browser are protected too.

---

## 7. Deploying publicly (optional)

The repo contains `Procfile`, `build.sh`, `render.yaml` and uses **WhiteNoise** for static files, so it works on Render or Railway:

**Render:** create a *Blueprint* from the repo (it reads `render.yaml`), or a *Web Service* with
* Build command: `./build.sh`
* Start command: `gunicorn config.wsgi:application`
* Environment: `DJANGO_DEBUG=0`, `DJANGO_SECRET_KEY=<random>`, `DJANGO_ALLOWED_HOSTS=.onrender.com`, `DJANGO_CSRF_TRUSTED_ORIGINS=https://*.onrender.com`

**Railway:** same build/start commands and the same environment variables (`DJANGO_ALLOWED_HOSTS=.up.railway.app`).

Production checklist (already handled in `config/settings.py`): debug off via env var, allowed hosts from env, secret key from env, static files collected and served by WhiteNoise.
The model files total about 10 MB, small enough to commit to GitHub.

---

## 8. Honest limitations

* **Only daily data exist**, so the **hourly curve is an estimate**: a smooth day/night cycle shaped by the forecast min/max and the sunrise time. It is not an hourly model.
* The models were trained on **one grid cell (Alexandria) for 5 years**. Without fresh readings, dates far after 2025-12-01 are a **seasonal estimate** (the confidence label says so). With readings, trust the first 2-3 days; after about a week any univariate model has little day-specific skill.
* **Pressure** is not in the NASA POWER pull from Task 4, so it is not an input.
* Weather *types* (sunny, rainy, windy...) are derived from the forecast cloud cover, wind, humidity and rain probability with transparent rules (`ml/weather_logic.py`); they are not a separate trained classifier.
* The 95 % interval is for the **mean temperature**; individual hours and the daily max/min are wider.
* Model files are Python pickles tied to the library versions in `requirements.txt`. If you change versions, run `python manage.py train_models`. Only load model files you trust.

---

## 9. Rubric and deliverables checklist

| Rubric | Where |
|---|---|
| Model integration (30 %) | Models loaded once in `apps.py` → `predictor.get_registry()`; parity test with the notebook |
| UI/UX (30 %) | Animated weather sky, glass cards, responsive layout (desktop + mobile screenshots), inline feedback, colour-coded result panel |
| Code structure (20 %) | `ml/` vs `forms.py` vs `views.py` (section 4) |
| Input validation (10 %) | Section 6, covered by tests |
| Documentation (10 %) | This README |

Deliverables: GitHub repo (push this folder) · screenshots in `docs/screenshots/` (form + result states) · this README · live link (optional, section 7).

Bonus challenges done: confidence chart · multiple models dropdown · JSON API · prediction caching.

## Credits
Weather data: NASA POWER. Continent outlines: Natural Earth (public domain). Model: Task 5 SARIMA-F.
