#!/usr/bin/env bash
# Build step used by Render / Railway: install dependencies and collect static files.
set -o errexit
pip install -r requirements.txt
python manage.py collectstatic --no-input
