from datetime import timedelta

from django.http import JsonResponse
from django.shortcuts import render

from .forms import MAX_DATE, OBS, ForecastForm
from .ml import predictor, service


def _default_inputs():
    reg = predictor.get_registry()
    d = min(max(service.today_cairo() + timedelta(days=1), reg.min_date), MAX_DATE)
    return {"date": d, "model": "temperature"}


def index(request):
    """Single page: form + forecast result. The form is submitted with GET so every forecast has a shareable URL."""
    submitted = bool(request.GET)
    form = ForecastForm(request.GET) if submitted else ForecastForm(initial=_default_inputs())
    valid = submitted and form.is_valid()
    # first visit, or invalid input: keep the page alive with the default forecast behind the error messages
    payload = service.forecast_payload(form.cleaned_data if valid else _default_inputs())
    reg = predictor.get_registry()
    ctx = {"form": form, "payload": payload, "stale": submitted and not valid, "has_errors": submitted and not valid,
           "obs_units": {k: v[5] for k, v in OBS.items()}, "min_date": reg.min_date.isoformat(), "max_date": MAX_DATE.isoformat()}
    return render(request, "forecast/index.html", ctx)


def api_forecast(request):
    """JSON API (bonus): same inputs as the form, e.g.  /api/forecast/?date=2026-12-15&temperature=14.5&humidity=88"""
    form = ForecastForm(request.GET)
    if not form.is_valid():
        return JsonResponse({"ok": False, "errors": form.errors.get_json_data()}, status=400)
    payload = service.forecast_payload(form.cleaned_data)
    slim = {k: payload[k] for k in ("meta", "observed", "location", "date", "daily", "atmosphere")}
    slim["hourly"] = payload["hourly_raw"]
    return JsonResponse({"ok": True, **slim}, json_dumps_params={"indent": 2})
