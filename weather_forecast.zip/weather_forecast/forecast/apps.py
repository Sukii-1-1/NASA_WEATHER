import logging

from django.apps import AppConfig

log = logging.getLogger(__name__)


class ForecastConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "forecast"

    def ready(self):
        # Load the serialised models ONCE when the server starts; every request then reuses them from memory.
        try:
            from .ml import predictor
            predictor.get_registry()
        except FileNotFoundError:
            log.warning("Model artifacts not found. Run `python manage.py train_models` first.")
