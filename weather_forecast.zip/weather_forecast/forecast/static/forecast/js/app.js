/* Page behaviour: hourly selection -> hero + sky, 7-day chart, presets, inline validation, animations toggle, API link. */
(function () {
  "use strict";
  const P = JSON.parse(document.getElementById("payload").textContent);
  const $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const heroTemp = $("#hero-temp"), heroCap = $("#hero-caption"), body = document.body;
  const meanText = Math.round(P.hero.tmean) + "°";

  /* ---- sky scene ---- */
  if (window.Sky) window.Sky.setScene(P.scene);
  function setHour(h) {
    const item = P.hourly_raw[h]; if (!item) return;
    $$(".hour", $("#hours")).forEach((b) => b.classList.toggle("active", Number(b.dataset.hour) === h && b.tagName === "BUTTON"));
    heroTemp.textContent = Math.round(item.temp_exact) + "°";
    heroCap.textContent = "At " + String(h).padStart(2, "0") + ":00 · estimated from the daily forecast";
    const scene = item.is_day ? P.scene_day : P.scene_night;
    if (window.Sky) window.Sky.setScene(scene);
    body.classList.toggle("is-day", item.is_day); body.classList.toggle("is-night", !item.is_day);
    const use = $("#hero-icon use"); if (use) use.setAttribute("href", "#i-" + item.icon);
    const night = { "Sunny": "Clear", "Hot & sunny": "Clear & warm", "Partly cloudy": "Partly cloudy" };
    $("#hero-cond").textContent = item.is_day ? P.hero.condition.label : (night[P.hero.condition.label] || P.hero.condition.label);
  }
  $$(".hour[data-hour]").forEach((b) => b.addEventListener("click", () => setHour(Number(b.dataset.hour))));
  heroCap.addEventListener("click", () => { heroTemp.textContent = meanText; heroCap.textContent = "Predicted mean temperature"; $("#hero-cond").textContent = P.hero.condition.label; const u = $("#hero-icon use"); if (u) u.setAttribute("href", "#i-" + P.hero.condition.icon); });
  heroCap.style.cursor = "pointer"; heroCap.title = "Click to show the daily mean again";
  const act = $(".hour.active"); if (act) $("#hours").scrollLeft = act.offsetLeft - $("#hours").clientWidth / 2 + act.clientWidth / 2;

  /* ---- hero count-up ---- */
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const end = Math.round(P.hero.tmean), t0 = performance.now(); heroTemp.textContent = "0°";
    (function tick(now) { const k = Math.min(1, (now - t0) / 800); heroTemp.textContent = Math.round(end * (1 - Math.pow(1 - k, 3))) + "°"; if (k < 1) requestAnimationFrame(tick); })(t0);
  }

  /* ---- wind fan speed ---- */
  const fan = $("#fan"); if (fan) fan.style.setProperty("--dur", Math.max(0.6, 6 - P.hero.wind * 0.9) + "s");

  /* ---- 7-day chart with confidence band (SVG) ---- */
  (function chart() {
    const el = $("#chart"), d = P.chart, W = 640, H = 230, m = { l: 34, r: 16, t: 24, b: 34 };
    const lo = Math.floor(Math.min(...d.map((x) => x.lo)) - 1), hi = Math.ceil(Math.max(...d.map((x) => x.hi)) + 1);
    const X = (i) => m.l + (i * (W - m.l - m.r)) / (d.length - 1), Y = (v) => m.t + ((hi - v) * (H - m.t - m.b)) / (hi - lo);
    let s = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet">`;
    const step = Math.max(1, Math.round((hi - lo) / 5));
    for (let v = lo; v <= hi; v += step) s += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="rgba(255,255,255,.12)"/><text x="${m.l - 8}" y="${Y(v) + 4}" text-anchor="end">${v}°</text>`;
    const up = d.map((x, i) => `${X(i)},${Y(x.hi)}`).join(" "), dn = d.map((x, i) => `${X(i)},${Y(x.lo)}`).reverse().join(" ");
    s += `<defs><linearGradient id="band" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fd4ff" stop-opacity=".45"/><stop offset="1" stop-color="#8c9bff" stop-opacity=".18"/></linearGradient></defs>`;
    s += `<polygon points="${up} ${dn}" fill="url(#band)"/>`;
    s += `<polyline points="${d.map((x, i) => `${X(i)},${Y(x.mean)}`).join(" ")}" fill="none" stroke="#fff" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>`;
    d.forEach((x, i) => { s += `<circle cx="${X(i)}" cy="${Y(x.mean)}" r="5" fill="#fff"/><text x="${X(i)}" y="${Y(x.mean) - 11}" text-anchor="middle" font-weight="700" style="fill:#fff;font-size:13px">${Math.round(x.mean)}°</text><text x="${X(i)}" y="${H - 10}" text-anchor="middle">${x.label === "Today" || x.label === "Tomorrow" ? x.short.split(" ")[0] : x.label}</text>`; });
    el.innerHTML = s + "</svg>";
  })();

  /* ---- scenario presets ---- */
  const PRESETS = {
    hot:    { date: "2026-07-16", temperature: 33, humidity: 55, wind_speed: 3, cloud_cover: 5, precipitation: 0 },
    storm:  { date: "2026-12-14", temperature: 14.5, humidity: 90, wind_speed: 6.8, cloud_cover: 95, precipitation: 14 },
    windy:  { date: "2026-03-20", temperature: 18, humidity: 60, wind_speed: 8.5, cloud_cover: 30, precipitation: 0 },
    cloudy: { date: "2026-02-03", temperature: 13, humidity: 72, wind_speed: 3, cloud_cover: 96, precipitation: 0 },
    clear:  { date: "2026-10-28", temperature: "", humidity: "", wind_speed: "", cloud_cover: "", precipitation: "" },
  };
  const form = $("#forecast-form");
  $$(".preset").forEach((b) => b.addEventListener("click", () => {
    const p = PRESETS[b.dataset.preset]; Object.keys(p).forEach((k) => { const f = form.elements[k]; if (f) f.value = p[k]; }); form.submit();
  }));

  /* ---- inline validation (mirrors the server-side Django rules) ---- */
  const RULES = { temperature: ["Temperature", -5, 50, "°C"], humidity: ["Humidity", 0, 100, "%"], wind_speed: ["Wind speed", 0, 40, "m/s"], cloud_cover: ["Cloud cover", 0, 100, "%"], precipitation: ["Precipitation", 0, 300, "mm"] };
  function check(input) {
    const name = input.name, box = input.closest(".field"), err = $(`.err[data-for="${name}"]`, box); let msg = "";
    const raw = input.value.trim();
    if (name === "date") { if (!raw) msg = "Choose the date you want a forecast for."; else if (input.min && raw < input.min) msg = "Pick a date on or after " + input.min + "."; else if (input.max && raw > input.max) msg = "Pick a date on or before " + input.max + "."; }
    else if (RULES[name] && raw !== "") {
      const [label, a, b, u] = RULES[name], v = Number(raw);
      if (!isFinite(v)) msg = "Enter a valid number, e.g. " + (input.placeholder || "").replace("e.g. ", "") + ".";
      else if (v < a || v > b) msg = `${label} must be between ${a} and ${b} ${u}.`;
    }
    box.classList.toggle("has-error", !!msg); if (err) err.textContent = msg; return !msg;
  }
  $$("input", form).forEach((i) => { i.addEventListener("blur", () => check(i)); i.addEventListener("input", () => { if (i.closest(".field").classList.contains("has-error")) check(i); }); });
  form.addEventListener("submit", (e) => { const ok = $$("input", form).map(check).every(Boolean); if (!ok) { e.preventDefault(); const bad = $(".has-error input", form); if (bad) bad.focus(); } else { $$("input", form).forEach((i) => { if (i.value === "") i.disabled = true; }); } });
  const dateInput = form.elements.date; if (dateInput) { dateInput.min = document.body.dataset.min || ""; dateInput.max = document.body.dataset.max || ""; }

  /* ---- animations toggle + API link ---- */
  const tm = $("#toggle-motion");
  tm.addEventListener("click", () => { const on = tm.getAttribute("aria-pressed") !== "true"; tm.setAttribute("aria-pressed", on); tm.textContent = "Animations: " + (on ? "on" : "off"); if (window.Sky) window.Sky.setMotion(on); });
  const q = new URLSearchParams(location.search); if (![...q.keys()].length) { q.set("date", P.date); }
  const api = location.origin + "/api/forecast/?" + q.toString(); const al = $("#api-link"); if (al) al.textContent = api.replace(location.origin, "");
  $("#copy-api")?.addEventListener("click", (e) => { navigator.clipboard?.writeText(api); e.target.textContent = "Copied"; setTimeout(() => (e.target.textContent = "Copy"), 1400); });
})();
