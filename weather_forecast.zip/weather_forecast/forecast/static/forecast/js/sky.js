/* Animated weather sky: gradient, sun / moon / stars, drifting clouds, rain, lightning and wind streaks.
   The scene parameters come from the server (weather_logic.scene) and are smoothly blended when they change. */
(function () {
  "use strict";
  const cv = document.getElementById("sky");
  if (!cv) return;
  const ctx = cv.getContext("2d");
  let W = 0, H = 0, DPR = 1, motion = !matchMedia("(prefers-reduced-motion: reduce)").matches;
  const NUM = ["sun", "moon", "stars", "clouds", "rain", "storm", "wind", "haze"];
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  let cur = null, target = null, t = 0, last = performance.now(), flash = 0, nextFlash = 3, bolt = null;

  function setScene(s) {
    target = Object.assign({}, s, { topc: hex(s.top), botc: hex(s.bottom) });
    if (!cur) cur = JSON.parse(JSON.stringify(target));
    if (!motion) { cur = JSON.parse(JSON.stringify(target)); draw(0); }
  }
  function setMotion(on) { motion = on; if (!on && cur) draw(0); }

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = cv.width = Math.round(innerWidth * DPR); H = cv.height = Math.round(innerHeight * DPR);
    if (cur) draw(0);
  }
  addEventListener("resize", resize);

  /* ---------- pre-rendered cloud sprites (light + dark) ---------- */
  function sprite(w, h, dark, seed) {
    const c = document.createElement("canvas"); c.width = w; c.height = h; const g = c.getContext("2d");
    let s = seed; const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
    const col = dark ? "62,72,92" : "255,255,255";
    for (let i = 0; i < 11; i++) {
      const r = h * (0.28 + rnd() * 0.3), x = w * (0.16 + 0.68 * (i / 10)) + (rnd() - .5) * w * .06, y = h * (0.6 - rnd() * 0.28);
      const gr = g.createRadialGradient(x, y, r * 0.05, x, y, r);
      gr.addColorStop(0, `rgba(${col},${dark ? .95 : .92})`); gr.addColorStop(0.6, `rgba(${col},${dark ? .6 : .55})`); gr.addColorStop(1, `rgba(${col},0)`);
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
    }
    return c;
  }
  const clouds = [], N_CLOUDS = 13;
  for (let i = 0; i < N_CLOUDS; i++) {
    const w = 360 + (i * 97 % 280), h = w * 0.42;
    clouds.push({ x: (i / N_CLOUDS) * 1.4 - 0.2, y: 0.05 + ((i * 53) % 55) / 100, s: 0.7 + (i % 5) * 0.22, v: 0.012 + (i % 4) * 0.006, light: sprite(w, h, false, 11 + i * 7), dark: sprite(w, h, true, 31 + i * 5), w, h });
  }
  const stars = Array.from({ length: 170 }, (_, i) => ({ x: ((i * 7919) % 1000) / 1000, y: ((i * 104729) % 1000) / 1000 * 0.75, r: 0.5 + ((i * 31) % 10) / 10, p: i }));
  const drops = Array.from({ length: 650 }, (_, i) => ({ x: Math.random(), y: Math.random(), l: 10 + Math.random() * 16, v: 0.9 + Math.random() * 0.7 }));
  const streaks = Array.from({ length: 40 }, (_, i) => ({ x: Math.random(), y: Math.random() * 0.9, l: 0.08 + Math.random() * 0.16, v: 0.5 + Math.random() }));

  function lerpState(dt) {
    if (!target) return;
    const k = 1 - Math.exp(-dt * 3.2);
    NUM.forEach((n) => { cur[n] += (target[n] - cur[n]) * k; });
    cur.topc = cur.topc.map((v, i) => v + (target.topc[i] - v) * k); cur.botc = cur.botc.map((v, i) => v + (target.botc[i] - v) * k);
    cur.code = target.code; cur.is_day = target.is_day;
  }

  function draw(dt) {
    if (!cur) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H);
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, `rgb(${cur.topc.map(Math.round)})`); g.addColorStop(1, `rgb(${cur.botc.map(Math.round)})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    // stars
    if (cur.stars > 0.02) {
      ctx.fillStyle = "#fff";
      stars.forEach((s) => { ctx.globalAlpha = cur.stars * (0.45 + 0.55 * Math.sin(t * 1.5 + s.p)); ctx.beginPath(); ctx.arc(s.x * W, s.y * H, s.r * DPR, 0, 7); ctx.fill(); });
      ctx.globalAlpha = 1;
    }
    const sx = W * 0.8, sy = H * 0.19, R = Math.min(W, H);
    // sun
    if (cur.sun > 0.02) {
      const a = cur.sun * (1 - cur.clouds * 0.45), pulse = 1 + Math.sin(t * 0.8) * 0.03;
      const glow = ctx.createRadialGradient(sx, sy, 0, sx, sy, R * 0.55 * pulse);
      glow.addColorStop(0, `rgba(255,244,190,${0.95 * a})`); glow.addColorStop(0.25, `rgba(255,214,120,${0.45 * a})`); glow.addColorStop(1, "rgba(255,200,90,0)");
      ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
      const disc = ctx.createRadialGradient(sx, sy, 0, sx, sy, R * 0.065);
      disc.addColorStop(0, `rgba(255,255,235,${a})`); disc.addColorStop(1, `rgba(255,226,130,${a})`);
      ctx.fillStyle = disc; ctx.beginPath(); ctx.arc(sx, sy, R * 0.065, 0, 7); ctx.fill();
    }
    // moon
    if (cur.moon > 0.02) {
      const a = cur.moon * (1 - cur.clouds * 0.5);
      const glow = ctx.createRadialGradient(sx, sy, 0, sx, sy, R * 0.4);
      glow.addColorStop(0, `rgba(210,222,255,${0.5 * a})`); glow.addColorStop(1, "rgba(160,180,255,0)");
      ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = `rgba(247,243,205,${a})`; ctx.beginPath(); ctx.arc(sx, sy, R * 0.05, 0, 7); ctx.fill();
      ctx.fillStyle = `rgba(215,208,165,${0.5 * a})`;
      [[-.015, -.01, .012], [.014, .012, .009], [.005, -.025, .006]].forEach(([dx, dy, r]) => { ctx.beginPath(); ctx.arc(sx + dx * R, sy + dy * R, r * R, 0, 7); ctx.fill(); });
    }
    // heat haze
    if (cur.haze > 0.02) {
      const h = ctx.createLinearGradient(0, H * 0.45, 0, H);
      h.addColorStop(0, "rgba(255,170,60,0)"); h.addColorStop(1, `rgba(255,120,40,${0.38 * cur.haze})`);
      ctx.fillStyle = h; ctx.fillRect(0, H * 0.45, W, H * 0.55);
    }
    // clouds
    const dark = clamp(cur.rain * 0.95 + (cur.is_day ? 0 : 0.4) + (cur.clouds > 0.85 ? 0.25 : 0), 0, 1);
    clouds.forEach((c, i) => {
      const vis = clamp(cur.clouds * N_CLOUDS - i, 0, 1) * (0.55 + 0.45 * cur.clouds); if (vis <= 0.01) return;
      c.x += (c.v * (0.5 + cur.wind * 4.5) * dt) / (W / 1000 / DPR);
      if (c.x > 1.25) c.x = -0.35;
      const w = c.w * c.s * DPR * 1.25, h = c.h * c.s * DPR * 1.25, x = c.x * W, y = c.y * H;
      ctx.globalAlpha = vis * (1 - dark); if (ctx.globalAlpha > 0.01) ctx.drawImage(c.light, x, y, w, h);
      ctx.globalAlpha = vis * dark; if (ctx.globalAlpha > 0.01) ctx.drawImage(c.dark, x, y, w, h);
    });
    ctx.globalAlpha = 1;
    // wind streaks
    if (cur.wind > 0.2) {
      ctx.lineCap = "round"; ctx.lineWidth = 1.4 * DPR;
      const n = Math.floor(streaks.length * cur.wind);
      for (let i = 0; i < n; i++) {
        const s = streaks[i]; s.x += s.v * (0.15 + cur.wind * 0.55) * dt; if (s.x > 1.2) { s.x = -0.25; s.y = Math.random() * 0.9; }
        const x = s.x * W, y = s.y * H, l = s.l * W;
        ctx.strokeStyle = `rgba(255,255,255,${0.16 + 0.1 * cur.wind})`; ctx.beginPath(); ctx.moveTo(x, y);
        ctx.bezierCurveTo(x + l * 0.3, y - 6 * DPR, x + l * 0.6, y + 6 * DPR, x + l, y); ctx.stroke();
      }
    }
    // rain
    if (cur.rain > 0.02) {
      const n = Math.floor(drops.length * cur.rain), tilt = 0.12 + cur.wind * 0.5;
      ctx.strokeStyle = "rgba(190,215,255,.5)"; ctx.lineWidth = 1.2 * DPR; ctx.lineCap = "round"; ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const d = drops[i]; d.y += d.v * 1.25 * dt; d.x += d.v * tilt * 0.55 * dt; if (d.y > 1.05) { d.y = -0.05; d.x = Math.random() * 1.2 - 0.1; } if (d.x > 1.1) d.x -= 1.2;
        const x = d.x * W, y = d.y * H; ctx.moveTo(x, y); ctx.lineTo(x + d.l * tilt * DPR, y + d.l * DPR);
      }
      ctx.stroke();
    }
    // lightning
    if (cur.storm > 0.5 && motion) {
      nextFlash -= dt;
      if (nextFlash <= 0) { flash = 1; nextFlash = 3 + Math.random() * 5; bolt = makeBolt(); }
    }
    if (flash > 0.01) {
      ctx.fillStyle = `rgba(225,232,255,${flash * 0.5})`; ctx.fillRect(0, 0, W, H);
      if (bolt) { ctx.strokeStyle = `rgba(255,255,255,${flash})`; ctx.lineWidth = 2.5 * DPR; ctx.shadowColor = "#bcd0ff"; ctx.shadowBlur = 18 * DPR; ctx.beginPath(); bolt.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke(); ctx.shadowBlur = 0; }
      flash *= Math.exp(-dt * 5);
    }
  }
  function makeBolt() {
    let x = W * (0.2 + Math.random() * 0.6), y = H * 0.05; const pts = [[x, y]];
    while (y < H * (0.45 + Math.random() * 0.2)) { x += (Math.random() - 0.5) * 60 * DPR; y += (20 + Math.random() * 30) * DPR; pts.push([x, y]); }
    return pts;
  }
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (motion) { t += dt; lerpState(dt); draw(dt); }
    else if (target) { lerpState(0.5); draw(0); }
    requestAnimationFrame(frame);
  }
  resize();
  window.Sky = { setScene, setMotion };
  requestAnimationFrame(frame);
})();
