/* Rotating Earth globe (orthographic projection on a 2D canvas) built from Natural Earth continent outlines.
   The glow colour shows the "state of the atmosphere", the cloud patches follow the forecast cloud cover. */
(function () {
  "use strict";
  const cv = document.getElementById("globe");
  if (!cv) return;
  const ctx = cv.getContext("2d"), P = JSON.parse(document.getElementById("payload").textContent);
  const D2R = Math.PI / 180, ALEX = { lon: P.location.lon, lat: P.location.lat };
  let land = [], size = 0, DPR = 1, lam0 = (ALEX.lon - 25) * D2R, phi0 = 22 * D2R, dragging = false, spin = true, last = performance.now(), t = 0;
  let anim = null, resumeAt = 0;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const atm = P.atmosphere, cloudFrac = P.hero.cloud / 100, wet = P.scene.rain > 0, storm = P.scene.storm > 0;

  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const blobs = Array.from({ length: 90 }, () => ({ lon: rnd() * 360 - 180, lat: Math.asin(rnd() * 1.7 - 0.85) / D2R, s: 0.6 + rnd() * 0.9, k: rnd() }));
  // keep the clouds around Egypt/Mediterranean in step with the local forecast
  blobs.slice(0, 10).forEach((b, i) => { b.lon = ALEX.lon + (rnd() - 0.5) * 40; b.lat = ALEX.lat + (rnd() - 0.5) * 22; b.k = i / 10 * 0.6; });

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2); const r = cv.getBoundingClientRect(); size = Math.max(120, Math.round(r.width));
    cv.width = Math.round(size * DPR); cv.height = Math.round(size * DPR);
  }
  new ResizeObserver(() => { resize(); }).observe(cv);

  function proj(lon, lat) {
    const l = lon * D2R - lam0, p = lat * D2R, cp = Math.cos(p), sp = Math.sin(p);
    return [cp * Math.sin(l), Math.cos(phi0) * sp - Math.sin(phi0) * cp * Math.cos(l), Math.sin(phi0) * sp + Math.cos(phi0) * cp * Math.cos(l)];
  }
  function draw() {
    const S = size * DPR, cx = S / 2, cy = S / 2, R = S * 0.37;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, S, S);
    // atmosphere glow
    const glow = ctx.createRadialGradient(cx, cy, R * 0.96, cx, cy, R * 1.32);
    glow.addColorStop(0, hexA(atm.color, 0.75)); glow.addColorStop(0.35, hexA(atm.color, 0.28)); glow.addColorStop(1, hexA(atm.color, 0));
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(cx, cy, R * 1.32, 0, 7); ctx.fill();

    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.clip();
    const ocean = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
    ocean.addColorStop(0, "#2f86e0"); ocean.addColorStop(0.7, "#14529e"); ocean.addColorStop(1, "#0a2a5e");
    ctx.fillStyle = ocean; ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    // graticule
    ctx.strokeStyle = "rgba(255,255,255,.10)"; ctx.lineWidth = DPR * 0.8;
    for (let lon = -180; lon < 180; lon += 30) { ctx.beginPath(); for (let lat = -90; lat <= 90; lat += 5) { const [x, y, z] = proj(lon, lat); if (z > 0) ctx.lineTo(cx + R * x, cy - R * y); else ctx.moveTo(cx + R * x, cy - R * y); } ctx.stroke(); }
    for (let lat = -60; lat <= 60; lat += 30) { ctx.beginPath(); for (let lon = -180; lon <= 180; lon += 5) { const [x, y, z] = proj(lon, lat); if (z > 0) ctx.lineTo(cx + R * x, cy - R * y); else ctx.moveTo(cx + R * x, cy - R * y); } ctx.stroke(); }
    // continents
    ctx.fillStyle = "#4fae7b"; ctx.strokeStyle = "rgba(220,255,230,.55)"; ctx.lineWidth = DPR * 0.9;
    land.forEach((ring) => {
      let any = false; const pts = ring.map(([lon, lat]) => { const [x, y, z] = proj(lon, lat); if (z >= 0) any = true; return [x, y, z]; });
      if (!any) return;
      ctx.beginPath();
      pts.forEach(([x, y, z], i) => { if (z < 0) { const m = Math.hypot(x, y) || 1; x /= m; y /= m; } const px = cx + R * x, py = cy - R * y; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
      ctx.closePath(); ctx.fill(); ctx.stroke();
    });
    // clouds (amount follows the forecast cloud cover)
    blobs.forEach((b) => {
      if (b.k > cloudFrac) return; const [x, y, z] = proj(b.lon, b.lat); if (z < 0.05) return;
      const r = R * 0.16 * b.s * (0.55 + 0.45 * z), g = ctx.createRadialGradient(cx + R * x, cy - R * y, 0, cx + R * x, cy - R * y, r);
      const c = wet ? "190,205,230" : "255,255,255"; g.addColorStop(0, `rgba(${c},${0.62 * z})`); g.addColorStop(1, `rgba(${c},0)`);
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx + R * x, cy - R * y, r, 0, 7); ctx.fill();
    });
    // storm swirl over Egypt
    const [ax, ay, az] = proj(ALEX.lon, ALEX.lat);
    if (storm && az > 0) { ctx.strokeStyle = "rgba(210,190,255,.8)"; ctx.lineWidth = DPR * 2; for (let k = 0; k < 3; k++) { ctx.beginPath(); for (let a = 0; a < 5.5; a += 0.2) { const rr = (0.012 + 0.012 * a + k * 0.004) * R * 2; ctx.lineTo(cx + R * ax + Math.cos(a + t * 2 + k * 2.1) * rr, cy - R * ay + Math.sin(a + t * 2 + k * 2.1) * rr); } ctx.stroke(); } }
    // limb darkening + sun-side shine
    const sh = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.2, cx, cy, R * 1.02);
    sh.addColorStop(0, "rgba(255,255,255,.14)"); sh.addColorStop(0.6, "rgba(0,0,0,0)"); sh.addColorStop(1, "rgba(0,8,30,.62)");
    ctx.fillStyle = sh; ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    ctx.restore();
    // Alexandria marker
    if (az > 0.02) {
      const mx = cx + R * ax, my = cy - R * ay, pulse = (t * 1.4) % 1;
      ctx.strokeStyle = `rgba(255,255,255,${1 - pulse})`; ctx.lineWidth = DPR * 2; ctx.beginPath(); ctx.arc(mx, my, (5 + pulse * 18) * DPR * az, 0, 7); ctx.stroke();
      ctx.fillStyle = "#ff5a5f"; ctx.strokeStyle = "#fff"; ctx.lineWidth = DPR * 2; ctx.beginPath(); ctx.arc(mx, my, 5.5 * DPR, 0, 7); ctx.fill(); ctx.stroke();
      ctx.font = `600 ${12 * DPR}px system-ui, sans-serif`; ctx.fillStyle = "#fff"; ctx.shadowColor = "rgba(0,0,0,.7)"; ctx.shadowBlur = 6 * DPR;
      ctx.fillText("Alexandria " + Math.round(P.hero.tmean) + "°", mx + 10 * DPR, my - 8 * DPR); ctx.shadowBlur = 0;
    }
  }
  function hexA(h, a) { const [r, g, b] = [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16)); return `rgba(${r},${g},${b},${a})`; }

  function locate() {
    spin = false; resumeAt = performance.now() + 6000;
    const toLam = ALEX.lon * D2R; let d = ((toLam - lam0 + Math.PI) % (2 * Math.PI)) - Math.PI; if (d < -Math.PI) d += 2 * Math.PI;
    anim = { t0: performance.now(), dur: 900, l0: lam0, dl: d, p0: phi0, dp: 22 * D2R - phi0 };
  }
  document.getElementById("globe-locate")?.addEventListener("click", locate);
  let px = 0, py = 0;
  cv.addEventListener("pointerdown", (e) => { dragging = true; spin = false; anim = null; px = e.clientX; py = e.clientY; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener("pointermove", (e) => { if (!dragging) return; lam0 -= (e.clientX - px) * 0.007; phi0 = Math.max(-1.1, Math.min(1.1, phi0 + (e.clientY - py) * 0.006)); px = e.clientX; py = e.clientY; if (reduce) draw(); });
  const up = () => { dragging = false; resumeAt = performance.now() + 4000; };
  cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);

  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
    if (anim) { const k = Math.min(1, (now - anim.t0) / anim.dur), e = 1 - Math.pow(1 - k, 3); lam0 = anim.l0 + anim.dl * e; phi0 = anim.p0 + anim.dp * e; if (k >= 1) anim = null; }
    else if (!dragging && !spin && now > resumeAt) spin = true;
    if (spin && !reduce && !dragging) lam0 += dt * 0.12;                       // slow auto-rotation (~7 degrees / s)
    if (size) draw();
    if (!reduce || dragging || anim) requestAnimationFrame(frame); else setTimeout(() => requestAnimationFrame(frame), 400);
  }
  fetch(cv.dataset.land).then((r) => r.json()).then((d) => { land = d; resize(); lam0 = ALEX.lon * D2R; requestAnimationFrame(frame); spin = false; resumeAt = performance.now() + 2500; });
})();
