from datetime import date

from django import forms

from .ml import predictor
from .ml.service import MODEL_CHOICES

MAX_DATE = date(2027, 12, 31)

# (label, min, max, step, placeholder, unit) for every optional observation
OBS = {
    "temperature": ("Temperature", -5, 50, "0.1", "e.g. 24.5", "°C"),
    "humidity": ("Humidity", 0, 100, "1", "e.g. 65", "%"),
    "wind_speed": ("Wind speed", 0, 40, "0.1", "e.g. 3.5", "m/s"),
    "cloud_cover": ("Cloud cover", 0, 100, "1", "e.g. 40", "%"),
    "precipitation": ("Precipitation", 0, 300, "0.1", "e.g. 0", "mm"),
}


def _field(name):
    label, lo, hi, step, ph, unit = OBS[name]
    # Django applies "%" formatting to validator messages, so a literal percent sign must be escaped as "%%".
    msg = f"{label} must be between {lo} and {hi} {unit}.".replace("%", "%%")
    return forms.FloatField(
        required=False, min_value=lo, max_value=hi, label=f"{label} ({unit})",
        widget=forms.NumberInput(attrs={"step": step, "min": lo, "max": hi, "placeholder": ph, "inputmode": "decimal"}),
        error_messages={"invalid": f"Enter a valid number, e.g. {ph.replace('e.g. ', '')}.", "min_value": msg, "max_value": msg})


class ForecastForm(forms.Form):
    date = forms.DateField(
        label="Forecast date", input_formats=["%Y-%m-%d"], widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
        error_messages={"required": "Choose the date you want a forecast for.", "invalid": "Enter a valid date (YYYY-MM-DD)."})
    model = forms.ChoiceField(label="Model", choices=MODEL_CHOICES, initial="temperature", required=False)
    temperature = _field("temperature")
    humidity = _field("humidity")
    wind_speed = _field("wind_speed")
    cloud_cover = _field("cloud_cover")
    precipitation = _field("precipitation")

    def clean_date(self):
        d = self.cleaned_data["date"]
        lo = predictor.get_registry().min_date
        if d < lo or d > MAX_DATE:
            raise forms.ValidationError(f"Pick a date between {lo:%d %b %Y} and {MAX_DATE:%d %b %Y}.")
        return d

    def clean_model(self):
        return self.cleaned_data.get("model") or "temperature"

    def clean(self):
        data = super().clean()
        d = data.get("date")
        has_obs = any(data.get(f) is not None for f in OBS)
        lo = predictor.get_registry().min_date
        if d and has_obs and d <= lo and "date" not in self.errors:
            self.add_error("date", f"Readings describe the day before the forecast date. Pick a date after {lo:%d %b %Y} to use them.")
        return data
