"""Automated tests: model integration (matches the Task 5 notebook), form validation, views, JSON API and weather logic."""
from datetime import date

import numpy as np
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from forecast.forms import ForecastForm
from forecast.ml import astro, predictor, service
from forecast.ml import weather_logic as wl


class ModelIntegrationTests(TestCase):
    def setUp(self):
        self.reg = predictor.get_registry()

    def test_models_are_loaded_once_and_reused(self):
        self.assertIs(predictor.get_registry(), predictor.get_registry())

    def test_forecast_matches_task5_notebook_output(self):
        """The app's forecast for the 30 test days equals the reference forecast saved from the Task 5 pipeline."""
        ref = self.reg.reference
        out = self.reg.forecast("temperature", ref["date"].iloc[0], len(ref))
        np.testing.assert_allclose(out["mean"].values, ref["forecast"].values, atol=1e-6)
        np.testing.assert_allclose(out["lower"].values, ref["lower_95"].values, atol=1e-6)

    def test_task5_test_error_is_reproduced(self):
        ref = self.reg.reference
        mae = float(np.mean(np.abs(ref["actual"] - ref["forecast"])))
        self.assertAlmostEqual(mae, 0.73, delta=0.01)             # Task 5 notebook: 0.73 C on the 30-day test window

    def test_observation_pulls_the_forecast_towards_it(self):
        base = self.reg.forecast("temperature", "2026-07-16", 1)["mean"].iloc[0]
        hot = self.reg.forecast("temperature", "2026-07-16", 1, observed=40.0)["mean"].iloc[0]
        cold = self.reg.forecast("temperature", "2026-07-16", 1, observed=15.0)["mean"].iloc[0]
        self.assertGreater(hot, base)
        self.assertLess(cold, base)

    def test_seasonality_summer_warmer_than_winter(self):
        summer = self.reg.forecast("temperature", "2026-08-05", 1)["mean"].iloc[0]
        winter = self.reg.forecast("temperature", "2026-02-05", 1)["mean"].iloc[0]
        self.assertGreater(summer - winter, 8)

    def test_all_variables_are_in_physical_range(self):
        for name, lo, hi in [("humidity", 0, 100), ("cloud_cover", 0, 100), ("wind_speed", 0, 20), ("temperature", -10, 50)]:
            vals = self.reg.forecast(name, "2026-11-20", 14)["mean"]
            self.assertTrue(((vals >= lo) & (vals <= hi)).all(), name)

    def test_start_before_training_end_is_rejected(self):
        with self.assertRaises(ValueError):
            self.reg.forecast("temperature", "2025-11-01", 3)


class FormValidationTests(TestCase):
    def valid(self, **kw):
        data = {"date": "2026-12-14", "model": "temperature"}
        data.update(kw)
        return ForecastForm(data)

    def test_only_date_is_required(self):
        self.assertTrue(self.valid().is_valid())

    def test_missing_date(self):
        f = ForecastForm({})
        self.assertFalse(f.is_valid())
        self.assertIn("date", f.errors)

    def test_non_numeric_text(self):
        f = self.valid(temperature="warm")
        self.assertFalse(f.is_valid())
        self.assertIn("valid number", f.errors["temperature"][0])

    def test_out_of_range_values(self):
        for field, bad in [("humidity", "150"), ("humidity", "-1"), ("temperature", "80"), ("wind_speed", "-3"), ("cloud_cover", "101"), ("precipitation", "-5")]:
            f = self.valid(**{field: bad})
            self.assertFalse(f.is_valid(), f"{field}={bad}")
            self.assertIn(field, f.errors)

    def test_date_out_of_range(self):
        self.assertFalse(self.valid(date="2025-01-01").is_valid())
        self.assertFalse(self.valid(date="2035-01-01").is_valid())
        self.assertFalse(self.valid(date="not-a-date").is_valid())

    def test_observations_need_a_later_date(self):
        first_day = predictor.get_registry().min_date.isoformat()
        f = self.valid(date=first_day, temperature="20")
        self.assertFalse(f.is_valid())
        self.assertIn("date", f.errors)

    def test_valid_full_form(self):
        f = self.valid(temperature="24.5", humidity="65", wind_speed="3.5", cloud_cover="40", precipitation="0")
        self.assertTrue(f.is_valid(), f.errors)


class ViewTests(TestCase):
    def setUp(self):
        cache.clear()

    def test_home_page_renders_like_a_product(self):
        r = self.client.get(reverse("forecast:index"))
        self.assertEqual(r.status_code, 200)
        for text in ["Alexandria", "Forecast settings", "Hourly temperature", "7-day forecast", "Humidity", "Cloud cover", "Precipitation", "Wind", "Atmosphere"]:
            self.assertContains(r, text)

    def test_valid_submission_shows_prediction_on_same_page(self):
        r = self.client.get("/", {"date": "2026-12-14", "temperature": "14.5", "humidity": "90", "wind_speed": "6.8", "cloud_cover": "95", "precipitation": "14"})
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Thunderstorm")
        self.assertNotContains(r, "Please fix the highlighted fields")

    def test_invalid_submission_shows_inline_errors(self):
        r = self.client.get("/", {"date": "2026-12-14", "humidity": "150", "temperature": "abc"})
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Please fix the highlighted fields")
        self.assertContains(r, "Humidity must be between 0 and 100")
        self.assertContains(r, "Enter a valid number")

    def test_missing_date_error(self):
        r = self.client.get("/", {"temperature": "20"})
        self.assertContains(r, "Choose the date you want a forecast for.")

    def test_identical_inputs_are_cached(self):
        params = {"date": "2026-05-05", "temperature": "26"}
        first = self.client.get("/api/forecast/", params).json()
        second = self.client.get("/api/forecast/", params).json()
        self.assertFalse(first["meta"]["cached"])
        self.assertTrue(second["meta"]["cached"])
        self.assertEqual(first["daily"], second["daily"])

    def test_json_api(self):
        r = self.client.get("/api/forecast/", {"date": "2026-12-15", "temperature": "14.5", "humidity": "88"})
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertTrue(data["ok"])
        self.assertEqual(len(data["daily"]), 7)
        self.assertEqual(len(data["hourly"]), 24)
        self.assertIn("tmean", data["daily"][0])

    def test_json_api_validation_error(self):
        r = self.client.get("/api/forecast/", {"date": "2026-12-15", "humidity": "500"})
        self.assertEqual(r.status_code, 400)
        self.assertFalse(r.json()["ok"])

    def test_model_dropdown_changes_the_model(self):
        a = self.client.get("/api/forecast/", {"date": "2026-10-28", "model": "temperature"}).json()
        b = self.client.get("/api/forecast/", {"date": "2026-10-28", "model": "temperature_arima"}).json()
        self.assertNotEqual(a["meta"]["model_label"], b["meta"]["model_label"])


class WeatherLogicTests(TestCase):
    def test_classification(self):
        args = dict(wind_hi=4.5, wind_vhi=6.0)
        self.assertEqual(wl.classify(30, 20, 2, 0.05, 4, **args), "clear")
        self.assertEqual(wl.classify(36, 10, 2, 0.05, 4, **args), "hot")
        self.assertEqual(wl.classify(25, 55, 2, 0.05, 4, **args), "partly")
        self.assertEqual(wl.classify(25, 90, 2, 0.05, 4, **args), "cloudy")
        self.assertEqual(wl.classify(25, 30, 6, 0.05, 4, **args), "windy")
        self.assertEqual(wl.classify(15, 90, 2, 0.4, 4, **args), "showers")
        self.assertEqual(wl.classify(15, 90, 2, 0.7, 5, **args), "rain")
        self.assertEqual(wl.classify(15, 95, 7, 0.9, 6, **args), "storm")

    def test_sun_times_are_sensible(self):
        summer, winter = astro.sun_times(date(2026, 6, 21)), astro.sun_times(date(2026, 12, 21))
        self.assertLess(summer["sunrise"], summer["noon"])
        self.assertLess(summer["noon"], summer["sunset"])
        self.assertGreater(summer["sunset"] - summer["sunrise"], winter["sunset"] - winter["sunrise"] + 3)

    def test_hourly_curve_has_min_before_max(self):
        temps = wl.hourly_temperatures(18, 28, 18, astro.sun_times(date(2026, 10, 28)))
        self.assertEqual(len(temps), 24)
        self.assertLess(int(np.argmin(temps)), int(np.argmax(temps)))
        self.assertAlmostEqual(max(temps), 28, delta=0.6)

    def test_beaufort_scale(self):
        self.assertEqual(wl.beaufort(0.1)[1], "Calm")
        self.assertEqual(wl.beaufort(9.0)[0], 5)
