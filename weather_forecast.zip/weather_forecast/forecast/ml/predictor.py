"""Model registry: loads every serialised model ONCE and produces raw (numeric) forecasts.

No presentation logic lives here: it only turns (start date, number of days, optional observation) into numbers.

How a user observation is used
------------------------------
The models were fitted on data up to `trained_through`. If the user supplies the readings of the day before the forecast
date, we *extend* the fitted state-space model to that day (the days in between are treated as missing, which the Kalman
filter handles natively) and forecast from there. The estimated parameters are never changed, so the model is exactly
the Task 5 model, just conditioned on fresher data. Without an observation the forecast starts at the end of the training
data and (for distant dates) converges to the seasonal average.
"""
import functools
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from .common import fourier

ARTIFACTS = Path(__file__).resolve().parent.parent / "artifacts"
FILES = {"temperature": "temperature_sarimaf.joblib", "temperature_arima": "temperature_arima.joblib", "dtr": "dtr.joblib",
         "humidity": "humidity.joblib", "wind_speed": "wind_speed.joblib", "cloud_cover": "cloud_cover.joblib"}
CLIP = {"humidity": (5, 100), "wind_speed": (0.3, 20), "cloud_cover": (0, 100), "dtr": (3, 20), "temperature": (-10, 50), "temperature_arima": (-10, 50)}
DAY = pd.Timedelta(days=1)


class Registry:
    def __init__(self, folder=ARTIFACTS):
        folder = Path(folder)
        self.meta = json.loads((folder / "metadata.json").read_text())
        self.train_end = pd.Timestamp(self.meta["trained_through"])
        self.models = {name: joblib.load(folder / fn) for name, fn in FILES.items()}      # loaded once, kept in memory
        self.K = {n: self.meta["models"][n]["K"] for n in FILES}
        self.reference = pd.read_csv(folder / "notebook_reference_forecast.csv", parse_dates=["date"])
        self.min_date = (self.train_end + DAY).date()                                       # first day the models can forecast

    def lead_days(self, start):
        """Days between the end of the training data and the day before `start` (0 means 'directly after training')."""
        return (pd.Timestamp(start).normalize() - self.train_end).days - 1

    def forecast(self, name, start, n_days, observed=None):
        """Forecast variable `name` for n_days starting at `start`. Returns DataFrame(mean, lower, upper) indexed by date."""
        start = pd.Timestamp(start).normalize()
        K, res = self.K[name], self.models[name]
        lead = self.lead_days(start)
        if lead < 0:
            raise ValueError(f"start date must be on or after {self.min_date}")
        future = pd.date_range(start, periods=n_days, freq="D")
        if observed is not None and lead >= 1:
            gap = pd.date_range(self.train_end + DAY, start - DAY, freq="D")             # days with no data ...
            endog = pd.Series(np.nan, index=gap)
            endog.iloc[-1] = float(observed)                                              # ... except the day before `start`
            res = res.extend(endog, exog=fourier(gap, K))
            fc = res.get_forecast(n_days, exog=fourier(future, K))
            mean, ci = fc.predicted_mean, fc.conf_int(0.05)
        else:                                                                             # no usable observation
            idx = pd.date_range(self.train_end + DAY, periods=lead + n_days, freq="D")
            fc = res.get_forecast(len(idx), exog=fourier(idx, K))
            mean, ci = fc.predicted_mean.iloc[lead:], fc.conf_int(0.05).iloc[lead:]
        lo, hi = CLIP.get(name, (-np.inf, np.inf))
        return pd.DataFrame({"mean": np.clip(mean.values, lo, hi), "lower": np.clip(ci.iloc[:, 0].values, lo, hi),
                             "upper": np.clip(ci.iloc[:, 1].values, lo, hi)}, index=future)

    def rain_probability(self, dates, cloud, humidity, wet_yesterday=None):
        """Probability of a wet day (>= 1 mm) from the season + the forecast cloud cover and humidity."""
        cfg = self.meta["precipitation"]
        X = np.column_stack([np.ones(len(dates)), fourier(dates, 2).values, np.asarray(cloud) / 100, np.asarray(humidity) / 100])
        z = X @ np.array(cfg["coef"])
        if wet_yesterday:                                  # wet spells persist: boost day 0 only
            z[0] += cfg["wet_persistence_log_odds"]
        return 1 / (1 + np.exp(-z))

    def wet_amount(self, dates):
        table = self.meta["precipitation"]["wet_amount_by_month"]
        return np.array([table[str(pd.Timestamp(d).month)] for d in dates])

    @property
    def climate(self):
        return self.meta["climate"]

    @property
    def share_above_mean(self):
        return self.meta["models"]["dtr"]["share_above_mean"]


@functools.lru_cache(maxsize=1)
def get_registry():
    return Registry()
