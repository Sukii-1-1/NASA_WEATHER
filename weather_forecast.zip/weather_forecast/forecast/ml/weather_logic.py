"""Turns raw numbers into weather concepts: condition, scene parameters, hourly curve, atmosphere state."""
import math

CONDITIONS = {   # code: (label, icon-day, icon-night)
    "clear": ("Sunny", "sun", "moon"), "hot": ("Hot & sunny", "hot", "moon"),
    "partly": ("Partly cloudy", "partly-day", "partly-night"), "cloudy": ("Cloudy", "cloud", "cloud"),
    "windy": ("Windy", "wind", "wind"), "showers": ("Showers", "showers", "showers"),
    "rain": ("Rain", "rain", "rain"), "heavy_rain": ("Heavy rain", "rain", "rain"), "storm": ("Thunderstorm", "storm", "storm"),
}
BEAUFORT = [(0.3, "Calm"), (1.6, "Light air"), (3.4, "Light breeze"), (5.5, "Gentle breeze"), (8.0, "Moderate breeze"), (10.8, "Fresh breeze"),
            (13.9, "Strong breeze"), (17.2, "Near gale"), (20.8, "Gale"), (24.5, "Strong gale"), (28.5, "Storm"), (32.7, "Violent storm")]


def beaufort(ms):
    for i, (limit, name) in enumerate(BEAUFORT):
        if ms < limit:
            return i, name
    return 12, "Hurricane"


def classify(tmax, cloud, wind, p_wet, amount_if_wet, wind_hi, wind_vhi):
    """Daily condition code from the forecast values (wind thresholds come from Alexandria's own climate)."""
    if p_wet >= 0.60 and (wind >= wind_hi or amount_if_wet >= 12):
        return "storm"
    if p_wet >= 0.50:
        return "heavy_rain" if amount_if_wet >= 10 else "rain"
    if p_wet >= 0.30 and cloud >= 60:
        return "showers"
    if wind >= wind_hi:
        return "windy"
    if cloud >= 75:
        return "cloudy"
    if cloud >= 40:
        return "partly"
    return "hot" if tmax >= 33 else "clear"


def condition_info(code, is_day=True):
    label, icon_day, icon_night = CONDITIONS[code]
    return {"code": code, "label": label, "icon": icon_day if is_day else icon_night}


def temp_word(t):
    for limit, word in [(12, "Cold"), (18, "Cool"), (24, "Mild"), (30, "Warm"), (35, "Hot")]:
        if t < limit:
            return word
    return "Very hot"


_PALETTE = {   # code: ((top, bottom) day, (top, bottom) night)
    "clear": (("#1f6fe5", "#8fd3ff"), ("#050a22", "#1c2c63")), "hot": (("#e8762b", "#ffd38a"), ("#2b1930", "#7a3f3a")),
    "partly": (("#3a7bd5", "#a6cdf0"), ("#0a1230", "#2c3d73")), "cloudy": (("#5f7188", "#b0bcc9"), ("#171f2e", "#3b475c")),
    "windy": (("#2f86d6", "#bfe3f7"), ("#0a1535", "#35487f")), "showers": (("#42536a", "#8696ab"), ("#111823", "#2d3a4b")),
    "rain": (("#34445a", "#6b7e95"), ("#0d131c", "#26323f")), "heavy_rain": (("#26323f", "#566a82"), ("#080c12", "#1d2833")),
    "storm": (("#1b1c33", "#4a4b6e"), ("#06070f", "#25263f")),
}


def scene(code, is_day, cloud, wind, p_wet, wind_hi):
    """Parameters for the animated sky (palette, sun/moon, stars, clouds, rain, lightning, wind)."""
    top, bottom = _PALETTE[code][0 if is_day else 1]
    rainy = code in ("showers", "rain", "heavy_rain", "storm")
    rain = {"showers": 0.35, "rain": 0.65, "heavy_rain": 1.0, "storm": 0.9}.get(code, 0.0)
    return {"code": code, "is_day": bool(is_day), "top": top, "bottom": bottom,
            "sun": 1 if (is_day and code in ("clear", "hot", "partly", "windy")) else 0,
            "moon": 1 if ((not is_day) and code in ("clear", "hot", "partly", "windy")) else 0,
            "stars": 0 if (is_day or rainy or code == "cloudy") else round(max(0.25, 1 - cloud / 100), 2),
            "clouds": round(max(0.15 if code != "clear" else 0.05, cloud / 100), 2), "rain": rain, "storm": 1 if code == "storm" else 0,
            "wind": round(min(1.0, wind / (wind_hi * 1.5)), 2), "haze": 1 if code == "hot" else 0}


def hourly_temperatures(tmin, tmax, tmin_next, sun):
    """24 hourly temperatures for one day from the forecast min/max, using a smooth (cosine) diurnal cycle.

    The coldest time is shortly after sunrise and the warmest about 3 h after solar noon.
    Only daily data exist, so these hourly values are an estimate shaped by the model's daily min/max."""
    t_min_time = min(max(sun["sunrise"] + 0.4, 3.0), 8.0)
    t_max_time = min(sun["noon"] + 3.0, 17.5)
    keys = [(t_max_time - 24, tmax), (t_min_time, tmin), (t_max_time, tmax), (t_min_time + 24, tmin_next)]
    out = []
    for h in range(24):
        for (h0, v0), (h1, v1) in zip(keys, keys[1:]):
            if h0 <= h <= h1:
                out.append(v0 + (v1 - v0) * (1 - math.cos(math.pi * (h - h0) / (h1 - h0))) / 2)
                break
    return out


def atmosphere(code, cloud, humidity, wind, wind_hi):
    """Overall 'state of the atmosphere' shown on the globe: label, glow colour and a one-line explanation."""
    if code == "storm":
        return {"label": "Turbulent", "color": "#b57bff", "detail": "Thunderstorm conditions with heavy cloud and strong air movement"}
    if code in ("rain", "heavy_rain", "showers"):
        return {"label": "Unsettled", "color": "#4aa8ff", "detail": "Moist, cloudy air with a good chance of rain"}
    if code == "windy":
        return {"label": "Breezy", "color": "#3fe0d0", "detail": "Fast-moving air masses, clear to partly cloudy"}
    if humidity >= 75:
        return {"label": "Humid", "color": "#4fd1a5", "detail": "Moist, heavy air near the Mediterranean coast"}
    if cloud >= 75:
        return {"label": "Overcast", "color": "#aab8c8", "detail": "Thick cloud layer, stable air"}
    if cloud >= 40:
        return {"label": "Fair", "color": "#7fc4ff", "detail": "Mixed sun and cloud, stable air"}
    hot = code == "hot"
    return {"label": "Hot & dry" if hot else "Clear & dry", "color": "#ff8a3d" if hot else "#ffcf5c",
            "detail": "Strong heating under clear skies" if hot else "Clear skies and low humidity"}


def confidence(day_index, anchored, lead):
    """Honest confidence label for a forecast day."""
    if anchored or lead == 0:
        return "High" if day_index == 0 else ("Good" if day_index <= 2 else "Moderate")
    return "Seasonal estimate"
