"""Shared helpers: calendar (Fourier) features and cleaning, identical to the Task 5 notebook."""
import numpy as np
import pandas as pd

T0 = pd.Timestamp("2021-01-01")      # origin of the Fourier time axis (first day of the dataset)
PERIOD = 365.25                      # yearly cycle in days


def fourier(idx, K, t0=T0, period=PERIOD):
    """Deterministic sine/cosine terms for the yearly cycle (they only depend on the calendar date)."""
    if K == 0:
        return None
    idx = pd.DatetimeIndex(idx)
    t = np.asarray((idx - t0).days, dtype=float)
    cols = {}
    for k in range(1, K + 1):
        cols[f"sin{k}"] = np.sin(2 * np.pi * k * t / period)
        cols[f"cos{k}"] = np.cos(2 * np.pi * k * t / period)
    return pd.DataFrame(cols, index=idx)


def winsorize_rolling(y, window=31, z=3.0):
    """Cap values to the local rolling mean +/- z std (Task 5 outlier rule: cap, never delete)."""
    m = y.rolling(window, center=True, min_periods=10).mean()
    s = y.rolling(window, center=True, min_periods=10).std()
    return y.clip(lower=m - z * s, upper=m + z * s)
