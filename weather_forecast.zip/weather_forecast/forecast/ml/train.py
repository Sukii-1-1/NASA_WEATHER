"""Train and serialise every model used by the web app.

Run with:  python manage.py train_models
The temperature model (SARIMA-F, order (2,1,1) + one yearly harmonic) is exactly the Task 5 model, fitted on the same
training split (everything before the last 30 days), so the app reproduces the notebook forecasts.
"""
import json
import time
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.statespace.sarimax import SARIMAX

from .common import fourier, winsorize_rolling

warnings.filterwarnings("ignore")
TEST_DAYS = 30


def fit(series, order, K):
    # Models WITHOUT differencing need a constant, otherwise their forecasts decay towards 0 instead of the series mean.
    trend = "c" if order[1] == 0 else None
    return SARIMAX(series, exog=fourier(series.index, K), order=order, trend=trend).fit(disp=False, maxiter=200)


def forecast(order, K, train, future_idx):
    r = fit(train, order, K)
    return r.get_forecast(len(future_idx), exog=fourier(future_idx, K)).predicted_mean.values


def walk_forward_mae(series, order, K, n_folds, h):
    """Rolling-origin MAE over the last n_folds*h days (refit at every origin)."""
    errs = []
    n = len(series)
    for f in range(n_folds):
        end = n - (n_folds - f) * h
        tr, te = series.iloc[:end], series.iloc[end:end + h]
        try:
            errs.append(np.mean(np.abs(te.values - forecast(order, K, tr, te.index))))
        except Exception:
            errs.append(np.nan)
    return float(np.nanmean(errs))


def baselines(series, K, n_folds, h):
    """Persistence and Fourier-climatology baselines on the same folds."""
    pers, clim = [], []
    n = len(series)
    for f in range(n_folds):
        end = n - (n_folds - f) * h
        tr, te = series.iloc[:end], series.iloc[end:end + h]
        pers.append(np.mean(np.abs(te.values - tr.iloc[-1])))
        ols = sm.OLS(tr, sm.add_constant(fourier(tr.index, K))).fit()
        pc = ols.predict(sm.add_constant(fourier(te.index, K), has_constant="add"))
        clim.append(np.mean(np.abs(te.values - pc.values)))
    return float(np.mean(pers)), float(np.mean(clim))


def run(csv_path, out_dir, log=print):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(csv_path, parse_dates=["date"], index_col="date").asfreq("D")
    df["temperature"] = winsorize_rolling(df["temperature"])
    df["dtr"] = df["temp_max"] - df["temp_min"]
    train_end = df.index[-TEST_DAYS - 1]
    train, test = df.loc[:train_end], df.loc[train_end + pd.Timedelta(days=1):]
    log(f"train {train.index[0].date()} -> {train_end.date()} ({len(train)} d) | test {len(test)} d")

    meta = {"trained_through": str(train_end.date()), "first_date": str(df.index[0].date()),
            "n_train": int(len(train)), "models": {}, "created": time.strftime("%Y-%m-%d %H:%M")}

    # ---- 1) temperature: Task 5 SARIMA-F and a non-seasonal ARIMA baseline ------------------------------------
    sarimaf = fit(train["temperature"], (2, 1, 1), 1)
    pred = sarimaf.get_forecast(TEST_DAYS, exog=fourier(test.index, 1))
    mean, ci = pred.predicted_mean, pred.conf_int(0.05)
    mae = float(np.mean(np.abs(test["temperature"].values - mean.values)))
    log(f"temperature SARIMA-F (2,1,1)+1 harmonic: 30-day test MAE = {mae:.3f} C")
    pd.DataFrame({"date": test.index.date, "actual": test["temperature"].values, "forecast": mean.values,
                  "lower_95": ci.iloc[:, 0].values, "upper_95": ci.iloc[:, 1].values}).to_csv(out_dir / "notebook_reference_forecast.csv", index=False)
    arima = fit(train["temperature"], (1, 0, 0), 0)
    meta["models"]["temperature"] = {"label": "SARIMA-F (2,1,1) + yearly harmonic (Task 5)", "order": [2, 1, 1], "K": 1, "test_mae_30d": mae}
    meta["models"]["temperature_arima"] = {"label": "ARIMA (1,0,0) + constant, no seasonal term (baseline)", "order": [1, 0, 0], "K": 0}
    joblib.dump(sarimaf, out_dir / "temperature_sarimaf.joblib", compress=3)
    joblib.dump(arima, out_dir / "temperature_arima.joblib", compress=3)

    # ---- 2) diurnal range (tmax - tmin) and the share of the range above the daily mean -----------------------
    joblib.dump(fit(train["dtr"], (1, 0, 1), 2), out_dir / "dtr.joblib", compress=3)
    above = ((train["temp_max"] - train["temperature"]) / train["dtr"]).replace([np.inf, -np.inf], np.nan).dropna()
    meta["models"]["dtr"] = {"order": [1, 0, 1], "K": 2, "share_above_mean": float(above.median())}

    # ---- 3) humidity, wind, cloud: choose a spec by walk-forward on TRAIN only ----------------------------------
    cands = [((1, 0, 1), 1), ((2, 0, 1), 2), ((1, 1, 1), 2), ((2, 1, 1), 1)]
    for var in ["humidity", "wind_speed", "cloud_cover"]:
        t0 = time.time()
        best = min(((walk_forward_mae(train[var], o, K, 3, 7), o, K) for o, K in cands), key=lambda s: s[0])
        joblib.dump(fit(train[var], best[1], best[2]), out_dir / f"{var}.joblib", compress=3)
        pers, clim = baselines(train[var], best[2], 3, 7)
        meta["models"][var] = {"order": list(best[1]), "K": best[2], "wf_mae_7d": best[0], "persistence_mae_7d": pers, "climatology_mae_7d": clim,
                               "units": {"humidity": "%", "wind_speed": "m/s", "cloud_cover": "%"}[var]}
        log(f"{var}: chose {best[1]} K={best[2]} WF-MAE {best[0]:.2f} | persistence {pers:.2f} | climatology {clim:.2f}  ({time.time()-t0:.0f}s)")

    # ---- 4) precipitation: wet-day probability (logistic) + typical wet-day amount ------------------------------
    wet = (train["precipitation"] >= 1.0).astype(int)
    X = np.column_stack([np.ones(len(train)), fourier(train.index, 2).values, train["cloud_cover"].values / 100, train["humidity"].values / 100])
    glm = sm.GLM(wet.values, X, family=sm.families.Binomial()).fit()
    p = glm.predict(X)
    brier, base = float(np.mean((p - wet.values) ** 2)), float(np.mean((wet.mean() - wet.values) ** 2))
    w = wet.values
    p_ww, p_wd = w[1:][w[:-1] == 1].mean(), w[1:][w[:-1] == 0].mean()
    persistence = float(np.log(p_ww / (1 - p_ww)) - np.log(p_wd / (1 - p_wd)))      # log-odds boost after a wet day
    amounts = train.loc[wet == 1, "precipitation"]
    cap = float(amounts.quantile(0.99))
    month_mean = amounts.clip(upper=cap).groupby(amounts.index.month).mean().reindex(range(1, 13))
    month_mean = month_mean.fillna(amounts.clip(upper=cap).mean())
    meta["precipitation"] = {"wet_threshold_mm": 1.0, "coef": [float(c) for c in glm.params],
                             "features": ["const", "sin1", "cos1", "sin2", "cos2", "cloud/100", "humidity/100"],
                             "brier": brier, "brier_base_rate": base, "wet_day_rate": float(wet.mean()), "wet_persistence_log_odds": persistence,
                             "wet_amount_by_month": {int(k): float(v) for k, v in month_mean.items()}}
    log(f"precipitation logit: Brier {brier:.4f} vs base-rate {base:.4f}; wet-day rate {wet.mean():.1%}")

    # ---- 5) climate tables used for thresholds and sanity checks ------------------------------------------------
    meta["climate"] = {"wind_p85": float(train["wind_speed"].quantile(0.85)), "wind_p95": float(train["wind_speed"].quantile(0.95)),
                       "monthly_mean": {v: {int(m): float(x) for m, x in train[v].groupby(train.index.month).mean().items()}
                                        for v in ["temperature", "temp_max", "temp_min", "humidity", "wind_speed", "cloud_cover", "precipitation"]}}
    (out_dir / "metadata.json").write_text(json.dumps(meta, indent=2))
    log("saved artifacts ->", out_dir)
    return meta
