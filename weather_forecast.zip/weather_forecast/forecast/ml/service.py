"""Builds the complete JSON-serialisable forecast 'payload' used by both the web page and the JSON API."""
import hashlib
import json
from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
from django.conf import settings
from django.core.cache import cache

from . import astro
from . import weather_logic as wl
from .predictor import get_registry

N_DAYS = 7
MODEL_CHOICES = [("temperature", "SARIMA-F: seasonal model (Task 5, recommended)"), ("temperature_arima", "ARIMA: baseline without seasonality")]
OBS_FIELDS = ["temperature", "humidity", "wind_speed", "cloud_cover", "precipitation"]
_STOPS = [(8, (74, 163, 255)), (16, (79, 209, 165)), (22, (255, 209, 102)), (29, (255, 159, 69)), (36, (255, 90, 60))]


def temp_color(t):
    """Colour for a temperature on a blue -> green -> yellow -> orange -> red scale."""
    if t <= _STOPS[0][0]:
        return "rgb(%d,%d,%d)" % _STOPS[0][1]
    for (t0, c0), (t1, c1) in zip(_STOPS, _STOPS[1:]):
        if t <= t1:
            f = (t - t0) / (t1 - t0)
            return "rgb(%d,%d,%d)" % tuple(round(a + (b - a) * f) for a, b in zip(c0, c1))
    return "rgb(%d,%d,%d)" % _STOPS[-1][1]


def today_cairo():
    return datetime.now(ZoneInfo(settings.TIME_ZONE)).date()


def _normalise(inputs):
    out = {"date": str(pd.Timestamp(inputs["date"]).date()), "model": inputs.get("model") or "temperature"}
    for f in OBS_FIELDS:
        v = inputs.get(f)
        out[f] = None if v in (None, "") else round(float(v), 3)
    return out


def forecast_payload(inputs):
    """Cached entry point: identical inputs return instantly (bonus: caching)."""
    norm = _normalise(inputs)
    key = "fc:" + hashlib.sha1(json.dumps(norm, sort_keys=True).encode()).hexdigest()
    hit = cache.get(key)
    if hit is not None:
        hit = dict(hit)
        hit["meta"] = {**hit["meta"], "cached": True}
        return hit
    payload = _build(norm)
    cache.set(key, payload, settings.FORECAST_CACHE_SECONDS)
    return payload


def _build(inp):
    reg = get_registry()
    start = pd.Timestamp(inp["date"])
    n = N_DAYS + 1                                            # one extra day: tomorrow's minimum shapes tonight's hourly curve
    obs = {f: inp[f] for f in OBS_FIELDS}
    lead = reg.lead_days(start)
    anchored = lead >= 1 and any(obs[f] is not None for f in ("temperature", "humidity", "wind_speed", "cloud_cover"))

    t = reg.forecast(inp["model"], start, n, obs["temperature"])
    dtr = reg.forecast("dtr", start, n)["mean"]
    hum = reg.forecast("humidity", start, n, obs["humidity"])["mean"]
    wind = reg.forecast("wind_speed", start, n, obs["wind_speed"])["mean"]
    cloud = reg.forecast("cloud_cover", start, n, obs["cloud_cover"])["mean"]
    dates = t.index
    wet_yesterday = obs["precipitation"] is not None and obs["precipitation"] >= 1.0 and lead >= 1
    p_wet = reg.rain_probability(dates, cloud.values, hum.values, wet_yesterday)
    amount = reg.wet_amount(dates)
    share = reg.share_above_mean
    tmean = t["mean"].values
    tmax, tmin = tmean + share * dtr.values, tmean - (1 - share) * dtr.values
    w_hi, w_vhi = reg.climate["wind_p85"], reg.climate["wind_p95"]

    today = today_cairo()
    daily, suns = [], []
    for i in range(n):
        d = dates[i].date()
        sun = astro.sun_times(d)
        suns.append(sun)
        code = wl.classify(tmax[i], cloud.iloc[i], wind.iloc[i], p_wet[i], amount[i], w_hi, w_vhi)
        bft, bft_name = wl.beaufort(wind.iloc[i])
        label = "Today" if d == today else ("Tomorrow" if (d - today).days == 1 else d.strftime("%a"))
        daily.append({"date": str(d), "label": label, "full": d.strftime("%A, %d %B %Y"), "short": d.strftime("%a %d %b"),
                      "tmean": round(float(tmean[i]), 1), "tmean_lo": round(float(t["lower"].iloc[i]), 1), "tmean_hi": round(float(t["upper"].iloc[i]), 1),
                      "tmax": round(float(tmax[i]), 1), "tmin": round(float(tmin[i]), 1),
                      "humidity": round(float(hum.iloc[i])), "cloud": round(float(cloud.iloc[i])), "wind": round(float(wind.iloc[i]), 1),
                      "beaufort": bft, "beaufort_name": bft_name, "p_wet": round(float(p_wet[i]), 2), "rain_pct": round(float(p_wet[i]) * 100),
                      "rain_mm": round(float(p_wet[i] * amount[i]), 1), "amount_if_wet": round(float(amount[i]), 1),
                      "condition": wl.condition_info(code), "temp_word": wl.temp_word(float(tmean[i])),
                      "confidence": wl.confidence(i, anchored, lead)})
    week = daily[:N_DAYS]
    g_lo, g_hi = min(d["tmin"] for d in week), max(d["tmax"] for d in week)
    span = max(g_hi - g_lo, 1.0)
    for d in week:                                           # geometry of the Apple-style temperature range bars
        d["bar_left"] = round((d["tmin"] - g_lo) / span * 100, 1)
        d["bar_width"] = round(max((d["tmax"] - d["tmin"]) / span * 100, 6), 1)
        d["color_lo"], d["color_hi"] = temp_color(d["tmin"]), temp_color(d["tmax"])

    # ---------- hourly strip for the selected day (Apple-Weather style)
    d0, sun0 = daily[0], suns[0]
    code0 = d0["condition"]["code"]
    temps = wl.hourly_temperatures(daily[0]["tmin"], daily[0]["tmax"], daily[1]["tmin"], sun0)
    now_hour = datetime.now(ZoneInfo(settings.TIME_ZONE)).hour if start.date() == today else None
    default_hour = now_hour if now_hour is not None else 14
    rainy = code0 in ("showers", "rain", "heavy_rain", "storm")
    hourly = []
    for h in range(24):
        is_day = sun0["sunrise"] <= h + 0.5 <= sun0["sunset"]
        hourly.append({"kind": "hour", "hour": h, "label": "Now" if h == now_hour else f"{h:02d}", "temp": round(temps[h]), "temp_exact": round(temps[h], 1),
                       "icon": wl.condition_info(code0, is_day)["icon"], "is_day": is_day, "rain_pct": d0["rain_pct"] if rainy else None})
    items = []
    for it in hourly:
        items.append(it)
        if int(sun0["sunrise"]) == it["hour"]:
            items.append({"kind": "sun", "label": sun0["sunrise_str"], "text": "Sunrise", "icon": "sunrise"})
        if int(sun0["sunset"]) == it["hour"]:
            items.append({"kind": "sun", "label": sun0["sunset_str"], "text": "Sunset", "icon": "sunset"})

    m = reg.meta["models"]
    model_meta = m["temperature"] if inp["model"] == "temperature" else m["temperature_arima"]
    notes = []
    if lead >= 1 and not anchored:
        notes.append("No recent observation entered, so this is the model's seasonal-climate estimate (the models were trained on data up to %s)." % reg.train_end.date())
    if anchored:
        notes.append("Forecast conditioned on your readings for %s. It is most reliable for the first 2-3 days, then relaxes towards the seasonal average." % (start - pd.Timedelta(days=1)).strftime("%d %b %Y"))
    if lead == 0:
        notes.append("This date directly follows the training data, so the numbers are exactly the Task 5 test forecast.")
    if inp["model"] == "temperature_arima":
        notes.append("ARIMA baseline selected: it ignores the yearly cycle, so it is expected to be less accurate than SARIMA-F.")

    chart = [{"label": d["label"], "short": d["short"], "mean": d["tmean"], "lo": d["tmean_lo"], "hi": d["tmean_hi"]} for d in week]
    scene = lambda is_day: wl.scene(code0, is_day, d0["cloud"], d0["wind"], d0["p_wet"], w_hi)
    return {
        "meta": {"model": inp["model"], "model_label": model_meta["label"], "anchored": anchored, "lead_days": lead, "cached": False,
                 "train_end": str(reg.train_end.date()), "test_mae": m["temperature"]["test_mae_30d"], "notes": notes},
        "observed": {k: v for k, v in obs.items() if v is not None},
        "location": {"name": "Alexandria", "country": "Egypt", "lat": astro.LAT, "lon": astro.LON},
        "date": inp["date"], "date_label": d0["full"], "hero": d0,
        "daily": week, "hourly": items, "hourly_raw": [{k: h[k] for k in ("hour", "temp_exact", "is_day", "icon")} for h in hourly],
        "default_hour": default_hour, "sun": {k: sun0[k] for k in ("sunrise_str", "sunset_str", "day_length")},
        "atmosphere": wl.atmosphere(code0, d0["cloud"], d0["humidity"], d0["wind"], w_hi), "chart": chart,
        "scene": scene(sun0["sunrise"] <= default_hour + 0.5 <= sun0["sunset"]), "scene_day": scene(True), "scene_night": scene(False),
    }
