"""Sunrise / sunset for the location (NOAA 'sunrise equation'). Used to decide day vs night and to place the temperature peak."""
import math
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

LAT, LON, TZ = 31.2001, 29.9187, "Africa/Cairo"      # Alexandria, Egypt


def sun_times(d: date, lat=LAT, lon=LON, tz=TZ):
    """Return dict(sunrise, sunset, noon) as decimal LOCAL hours plus formatted strings."""
    jd = d.toordinal() + 1721425.0                                   # Julian day number (noon) of the date
    n = jd - 2451545.0 + 0.0008
    j_star = n - lon / 360.0                                         # solar noon is EARLIER (in UT) the further east you are
    m = math.radians((357.5291 + 0.98560028 * j_star) % 360)
    c = 1.9148 * math.sin(m) + 0.02 * math.sin(2 * m) + 0.0003 * math.sin(3 * m)
    lam = math.radians((math.degrees(m) + c + 180 + 102.9372) % 360)
    j_transit = 2451545.0 + j_star + 0.0053 * math.sin(m) - 0.0069 * math.sin(2 * lam)
    sin_d = math.sin(lam) * math.sin(math.radians(23.4397))
    cos_d = math.cos(math.asin(sin_d))
    cos_w = (math.sin(math.radians(-0.833)) - math.sin(math.radians(lat)) * sin_d) / (math.cos(math.radians(lat)) * cos_d)
    w0 = math.degrees(math.acos(max(-1.0, min(1.0, cos_w))))
    zone = ZoneInfo(tz)

    def to_local(jd_val):
        utc = datetime(2000, 1, 1, 12, tzinfo=timezone.utc) + timedelta(days=jd_val - 2451545.0)
        return utc.astimezone(zone)

    rise, noon, sset = to_local(j_transit - w0 / 360), to_local(j_transit), to_local(j_transit + w0 / 360)
    dec = lambda t: t.hour + t.minute / 60 + t.second / 3600
    length = (sset - rise).total_seconds() / 3600
    return {"sunrise": dec(rise), "sunset": dec(sset), "noon": dec(noon),
            "sunrise_str": rise.strftime("%H:%M"), "sunset_str": sset.strftime("%H:%M"),
            "day_length": f"{int(length)}h {int(round((length % 1) * 60)):02d}m"}
