from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand

from forecast.ml import train


class Command(BaseCommand):
    help = "Train all forecasting models from data/alexandria_weather_clean.csv and save them to forecast/artifacts/"

    def handle(self, *args, **opts):
        csv = Path(settings.BASE_DIR) / "data" / "alexandria_weather_clean.csv"
        out = Path(settings.BASE_DIR) / "forecast" / "artifacts"
        train.run(csv, out, log=lambda *a: self.stdout.write(" ".join(str(x) for x in a)))
